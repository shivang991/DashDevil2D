import { test, expect } from '@playwright/test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const evidence = path.resolve('../docs/preservation/evidence');
test('public app: five-second start, actual canvas, keyboard pause and mute', async ({ page, browser }) => {
  await page.clock.install({ time: new Date('2026-10-14T19:00:00Z') });
  // Randomness seed at the platform boundary, not product internals.
  await page.addInitScript(() => { let seed = 21; Math.random = () => { seed = (1664525 * seed + 1013904223) >>> 0; return seed / 4294967296; }; });
  await page.goto('http://127.0.0.1:4173');
  await page.getByText('Solo Trip', { exact: true }).click();
  await expect(page.locator('.game-overlay')).toHaveText('5');
  const dimensions = await page.locator('canvas').evaluate(c => { const canvas = c as HTMLCanvasElement; const r = canvas.getBoundingClientRect(); return { width: canvas.width, height: canvas.height, css: { width: r.width, height: r.height } }; });
  fs.writeFileSync(path.join(evidence, 'browser-environment.json'), JSON.stringify({ baselineRevision: 'a68f27efd1d79ec8eea7ef0b0a6d8567606189dd', fixtureVersion: 1, randomSeed: 21, viewport: { width: 1280, height: 900 }, canvas: dimensions, browser: browser.version(), platform: os.platform(), release: os.release(), architecture: os.arch(), memoryBytes: os.totalmem(), cpu: os.cpus()[0].model, humanReview: 'pending', audioAudition: 'pending', powerSettings: 'unrecorded', referenceHardwareEquivalence: 'not established' }, null, 2));
  await page.screenshot({ path: path.join(evidence, 'baseline-countdown.png') });
  await page.clock.runFor(4900); await expect(page.locator('.game-overlay')).toHaveText('1');
  await page.clock.runFor(150); await expect(page.locator('.game-overlay')).toHaveCount(0);
  await expect(page.getByRole('img', { name: 'Health: 2 of 2' })).toBeVisible();
  await page.keyboard.down('ArrowUp'); await page.clock.runFor(400);
  await page.screenshot({ path: path.join(evidence, 'baseline-acceleration.png') });
  await page.keyboard.up('ArrowUp'); await page.keyboard.press('Space'); await page.clock.runFor(20);
  await expect(page.getByText('PAUSED', { exact: true })).toBeVisible();
  await page.screenshot({ path: path.join(evidence, 'baseline-pause.png') });
  await page.clock.runFor(5000); await expect(page.getByText('PAUSED', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Mute sound' }).click();
  await expect(page.getByRole('button', { name: 'Enable sound' })).toBeVisible();
  await page.reload(); await expect(page.getByRole('button', { name: 'Enable sound' })).toBeVisible();
});
