import { test, expect } from '@playwright/test';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
const evidence = path.resolve('../docs/preservation/evidence');
test('public app: five-second start, actual canvas, keyboard pause and mute', async ({ page, browser }) => {
  await page.clock.install({ time: new Date('2026-10-14T19:00:00Z') });
  await page.clock.pauseAt(new Date('2026-10-14T19:00:01Z'));
  // Randomness seed at the platform boundary, not product internals.
  await page.addInitScript(() => { let seed = 21; Math.random = () => { seed = (1664525 * seed + 1013904223) >>> 0; return seed / 4294967296; }; });
  await page.goto('http://127.0.0.1:4173');
  await page.getByText('Solo Trip', { exact: true }).click();
  await expect(page.locator('.game-overlay')).toHaveText('5');
  const dimensions = await page.locator('canvas').evaluate(c => { const canvas = c as HTMLCanvasElement; const r = canvas.getBoundingClientRect(); return { width: canvas.width, height: canvas.height, css: { width: r.width, height: r.height } }; });
  fs.writeFileSync(path.join(evidence, 'browser-environment.json'), JSON.stringify({ baselineRevision: 'a68f27efd1d79ec8eea7ef0b0a6d8567606189dd', fixtureVersion: 1, randomSeed: 21, viewport: { width: 1280, height: 900 }, canvas: dimensions, browser: browser.version(), platform: os.platform(), release: os.release(), architecture: os.arch(), memoryBytes: os.totalmem(), cpu: os.cpus()[0].model, humanReview: 'pending', audioAudition: 'pending', powerSettings: 'unrecorded', referenceHardwareEquivalence: 'not established' }, null, 2));
  await page.screenshot({ path: path.join(evidence, 'baseline-countdown.png') });
  await page.clock.runFor(4900); await expect(page.locator('.game-overlay')).toHaveText('1');
  await page.clock.runFor(150); await expect(page.locator('.game-overlay')).toHaveCount(0);
  await expect(page.getByRole('img', { name: 'Health: 2 of 2' })).toBeVisible();
  await page.keyboard.down('ArrowUp'); await page.clock.runFor(400);
  await page.screenshot({ path: path.join(evidence, 'baseline-acceleration.png') });
  await page.keyboard.up('ArrowUp'); await page.keyboard.press('Space'); await page.clock.runFor(20);
  await expect(page.getByText('PAUSED', { exact: true })).toBeVisible();
  await page.screenshot({ path: path.join(evidence, 'baseline-pause.png') });
  await page.clock.runFor(5000); await expect(page.getByText('PAUSED', { exact: true })).toBeVisible();
  await page.getByRole('button', { name: 'Mute sound' }).click();
  await expect(page.getByRole('button', { name: 'Enable sound' })).toBeVisible();
  await page.reload(); await expect(page.getByRole('button', { name: 'Enable sound' })).toBeVisible();
});

test('record real-time public presentation for later human comparison', async ({ page }) => {
  test.setTimeout(65000);
  // Capture Web Audio's actual output through a parallel platform recording sink.
  // This records audio bytes; it does not establish human-perceived equivalence.
  await page.addInitScript(`
    const NativeContext = window.AudioContext;
    const recordings = [];
    const sinks = new WeakMap();
    const originalConnect = AudioNode.prototype.connect;
    AudioNode.prototype.connect = function(...args) {
      const result = originalConnect.apply(this, args);
      const sink = sinks.get(this.context);
      if (sink && args[0] === this.context.destination) originalConnect.call(this, sink);
      return result;
    };
    window.AudioContext = class extends NativeContext {
      constructor(...args) {
        super(...args);
        const sink = this.createMediaStreamDestination();
        sinks.set(this, sink);
        const chunks = [];
        const recorder = new MediaRecorder(sink.stream);
        recorder.ondataavailable = e => chunks.push(e.data);
        recorder.start();
        recordings.push({ recorder, chunks });
      }
    };
    window.finishBaselineAudio = async () => {
      if (!recordings.length) return null;
      const { recorder, chunks } = recordings[0];
      await new Promise(resolve => { recorder.onstop = resolve; recorder.stop(); });
      return Array.from(new Uint8Array(await new Blob(chunks).arrayBuffer()));
    };
  `);
  await page.addInitScript(() => { let seed = 21; Math.random = () => { seed = (1664525 * seed + 1013904223) >>> 0; return seed / 4294967296; }; });
  await page.goto('http://127.0.0.1:4173');
  await page.getByText('Solo Trip', { exact: true }).click();
  await expect(page.locator('.game-overlay')).toHaveCount(0, { timeout: 7000 });
  await page.keyboard.down('ArrowUp'); await page.waitForTimeout(500);
  await page.keyboard.down('ArrowLeft'); await page.waitForTimeout(500);
  await page.keyboard.up('ArrowLeft'); await page.keyboard.up('ArrowUp');
  await page.keyboard.press('Space'); await expect(page.getByText('PAUSED', { exact: true })).toBeVisible();
  await page.keyboard.press('Space');
  await page.keyboard.down('ArrowRight'); await page.waitForTimeout(50); await page.keyboard.up('ArrowRight');
  await expect(page.getByText('GAME OVER', { exact: true })).toBeVisible({ timeout: 45000 });
  await page.screenshot({ path: path.join(evidence, 'baseline-gameover.png') });
  const audio = await page.evaluate('finishBaselineAudio()') as number[] | null;
  if (audio) fs.writeFileSync(path.join(evidence, 'baseline-audio.webm'), Buffer.from(audio));
  fs.writeFileSync(path.join(evidence, 'audio-capture.json'), JSON.stringify({ recordedBytes: audio?.length ?? 0, method: 'parallel Web Audio MediaStreamDestination', captures: ['countdown/GO', 'engine', 'acceleration/release', 'lane change', 'pause/resume', 'damage', 'gameover'], missing: ['coin cue not independently isolated', 'hidden-tab mute'], humanAudition: 'pending' }, null, 2));
  await page.setViewportSize({ width: 800, height: 600 });
  const dimensions = await page.locator('canvas').evaluate(c => ({ width: (c as HTMLCanvasElement).width, height: (c as HTMLCanvasElement).height }));
  fs.writeFileSync(path.join(evidence, 'resize-environment.json'), JSON.stringify({ viewport: { width: 800, height: 600 }, canvas: dimensions, collisionEquivalence: 'not established; #26 owns corrected geometry' }, null, 2));
  await page.screenshot({ path: path.join(evidence, 'baseline-resize-pause.png') });
});
